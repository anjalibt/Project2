from django.urls import path
from . import views

urlpatterns=[
    path('', views.home_view, name='home_view')
    path('data/', views.Retrieve_listview(), name='Retrive_Listview'),
    path('data/<int:_id>', views.Retrieve_Detailview(), name='Retrive_Detailview'),
    path('data/<int:_id>/deleteview', views.DeleteView, name="DeleteView"),
]


