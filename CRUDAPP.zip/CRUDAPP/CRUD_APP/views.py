from django.shortcuts import render

# Create your views here.
from . forms import EmployeeForm

'''def home_view(request):
    form = EmployeeForm()
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
    context = {
        'form' : form
    }
    return render(request, 'home.html', context)

home_view()'''

'''def Retrive_listView(request):
    dataset = path('data/', views.Retrieve_listview(), name='Retrive_Listview')
].objects.all()
    return render(request, 'listview.html', {'dataset': dataset})

def Retrive_DetailView(request, _id):
    try:
        data = Employee.objects.get(id = id)
    except Employee.DoesNotExist:
        raise Http404('Data does not exists')

    return render(request, 'detailview.html', {'data': data})'''


def DeleteView(request, _id):
    try:
        data= get_object_or_404(Employee, id = _id)
    except Exception:
        raise Http404('Data does not exists')
    if request.method == 'POST':
        data.delete()
        return redirect('/data')
    else:
        return render(request, 'deleteview.html')
